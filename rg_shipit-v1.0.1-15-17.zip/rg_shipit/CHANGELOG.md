# CHANGELOG

## 1.0.0 -- (2018, Feb 01)
[+] Initial release
